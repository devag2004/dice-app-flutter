import 'package:flutter/material.dart';
import 'package:i_am_rich/dice_roller.dart';
import 'package:i_am_rich/styledtext.dart';
import 'package:i_am_rich/functions.dart';
import 'package:i_am_rich/dice_roller.dart';

const startalignment = Alignment.topLeft;
const endalignment = Alignment.bottomRight;

class Gradientcontainer extends StatelessWidget {
  const Gradientcontainer(this.color1, this.color2, {super.key});
  const Gradientcontainer.purple({super.key})
      : color1 = Colors.deepPurple,
        color2 = Colors.purple;

  final Color color1;
  final Color color2;


  @override
  Widget build(context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color1, color2],
          begin: startalignment,
          end: endalignment,
        ),
      ),
      child: const Center(
          child: diceroller()),
    );
  }
}
