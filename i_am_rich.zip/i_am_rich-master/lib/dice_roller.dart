import 'package:flutter/material.dart';
import 'package:i_am_rich/functions.dart';
import 'dart:math';

class diceroller extends StatefulWidget{
  const diceroller({super.key});
  @override
  State<diceroller> createState() {
    return _dicerollerstate();
  }
}

class _dicerollerstate extends State<diceroller>{
  var activeimage = 'assets/dice.jpg';

  void rollDice(){
    var diceroll=Random().nextInt(6) + 1 ; //next int is max value excluded
    setState((){
    activeimage = 'assets/dice-$diceroll.png';
    });
  }

  @override
  Widget build(context){
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Image.asset(
        activeimage,
        width: 200,
      ),
      TextButton(
        onPressed: rollDice,
        style: TextButton.styleFrom(
            padding: const EdgeInsets.only(
              top: 20,
            ),
            foregroundColor: Colors.white,
            textStyle: const TextStyle(fontSize: 28)),
        child: const Text('Roll Dice'),
      )
    ]);
  }
}