import 'package:flutter/material.dart';
import 'package:i_am_rich/gradient_container.dart';

void main() {
  runApp(
    const MaterialApp(
      home: Scaffold(
        body: Gradientcontainer(Colors.pink, Colors.deepPurple),
      ),
    ),
  );
}
